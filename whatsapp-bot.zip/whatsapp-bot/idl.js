const { IDL } = require('@dfinity/candid');

const idlFactory = ({ IDL }) => {
  return IDL.Service({
    respondTo: IDL.Func([IDL.Text], [IDL.Record({ reply: IDL.Text })], ['query']),
  });
};

module.exports = { idlFactory };
