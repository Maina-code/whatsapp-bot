require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const fs = require('fs');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const PORT = process.env.PORT || 3000;

app.post('/whatsapp', async (req, res) => {
  const message = req.body.Body;
  const from = req.body.From;

  console.log(`📩 Received: ${message} from ${from}`);

  // Log the message
  fs.appendFileSync('messages.log', `${new Date().toISOString()} - ${from}: ${message}\n`);

  // Properly sanitize and format the 'to' number
  const cleanedFrom = from.trim().replace(/\s+/g, ''); // remove any spaces

  try {
    await client.messages.create({
      body: `🤖 Hello! You said: "${message}"`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: cleanedFrom
    });

    console.log('✅ Reply sent');
    res.sendStatus(200);
  } catch (err) {
    console.error("❌ Error sending reply:", err.message);
    if (err.response) {
      console.error("📨 Twilio Response:", err.response.data);
    }
    res.sendStatus(500);
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
